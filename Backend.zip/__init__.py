#!/usr/local/bin/python
# -*- coding: utf-8 -*-
from flask import Flask, render_template_string, abort, render_template, session, request, flash, redirect, url_for, jsonify, send_from_directory
import os
from flask_sqlalchemy import SQLAlchemy
import datetime
import uuid
import sys
import pyqrcode
import StringIO
import jwt
import datetime
from functools import wraps
from flask_mail import Message, Mail
from haversine import haversine
import numpy as np
import random

from decimal import Decimal

import face_recognition
import pickle

#sys.setdefaultencoding('utf-8') 

#app = Flask(__name__, static_url_path = "/static", static_folder = STATIC_FOLDER, subdomain_matching=True)

app = Flask(__name__)

STATIC_FOLDER = os.path.join(os.path.dirname(__file__), "static")

PHOTOS_FOLDER = os.path.join(STATIC_FOLDER, "photos")

TEMP_PHOTOS_FOLDER = os.path.join(STATIC_FOLDER, "temp")

app.config['STATIC_FOLDER'] = STATIC_FOLDER

app.config['PHOTOS_FOLDER'] = PHOTOS_FOLDER

app.config['TEMP_PHOTOS_FOLDER'] = TEMP_PHOTOS_FOLDER

app.config['SECRET_KEY'] = 'C66Q2pLSi5j4bf3rYJad8HAxTUpjzr8TpKpBfzmkUzScPwbTMeYL23RzCmiNwQqAgH6Q9UAiXUGkkxHC'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///Database.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

#app.config['SERVER_NAME'] = "flextubeapp.com"

app.config["MAIL_SERVER"] = "smtp.gmail.com"
app.config["MAIL_PORT"] = 465
app.config["MAIL_USE_SSL"] = True
app.config["MAIL_USERNAME"] = "hajj.hackathon.h16@gmail.com"
app.config["MAIL_PASSWORD"] = "Aa12341234"


# app.config['SERVER_NAME'] = 'localhost'

db = SQLAlchemy(app)
mail = Mail(app)

class Hajj_Management(db.Model):
    __tablename__ = 'hajj_management'

    id = db.Column(db.Integer, primary_key = True)
    name = db.Column(db.Text, server_default='')
    password = db.Column(db.Text, server_default='')
    secret_code = db.Column(db.Text, server_default='')
    device_token = db.Column(db.Text, server_default='')
    hamlat = db.relationship('Hamlat', backref='hajj_management', lazy='dynamic')
    announcemts = db.relationship('Hamlat_Announcements', backref='hamlah', lazy='dynamic')
    time = db.Column(db.DateTime, index=True, default=datetime.datetime.utcnow)

class Hamlat(db.Model):
	__tablename__ = "hamlat"

	id = db.Column(db.Integer, primary_key = True)
	hajj_management_id = db.Column(db.Integer, db.ForeignKey('hajj_management.id'))
	name = db.Column(db.Text, server_default='')
	email = db.Column(db.Text, server_default='')
	password = db.Column(db.Text, server_default='')
	secret_code = db.Column(db.Text, server_default='')
	device_token = db.Column(db.Text, server_default='')
	latitude = db.Column(db.Float(11), nullable=True, server_default= None)
	longitude = db.Column(db.Float(11), nullable=True, server_default= None)
	hujjaj = db.relationship('Hujjaj', backref='hamlah', lazy='dynamic')
	announcemts = db.relationship('Hujjaj_Announcements', backref='hujjaj', lazy='dynamic')
	time = db.Column(db.DateTime, index=True, default=datetime.datetime.utcnow)

class Hujjaj(db.Model):
	__tablename__ = "hujjaj"

	id = db.Column(db.Integer, primary_key = True)
	hamlah_id = db.Column(db.Integer, db.ForeignKey('hamlat.id'))
	name = db.Column(db.Text, server_default='')
	email = db.Column(db.Text, server_default='')
	photo_path = db.Column(db.Text, server_default='')
	secret_code = db.Column(db.Text, server_default='')
	device_token = db.Column(db.Text, server_default='')
	latitude = db.Column(db.Float(11), nullable=True, server_default= None)
	longitude = db.Column(db.Float(11), nullable=True, server_default= None)
	nationality = db.Column(db.Text, server_default='')
	bloodtype = db.Column(db.Text, server_default='')
	permission_number = db.Column(db.Integer, server_default=None)
	language = db.Column(db.Text, server_default='')
	leaving_date = db.Column(db.DateTime, nullable=True, default=None)
	time = db.Column(db.DateTime, index=True, default=datetime.datetime.utcnow)

class Hamlat_Announcements(db.Model):
	__tablename__ = "hamlat_announcements"

	id = db.Column(db.Integer, primary_key = True)
	hajj_management_id = db.Column(db.Integer, db.ForeignKey('hajj_management.id'))
	hamlah_id = db.Column(db.Integer, db.ForeignKey('hamlat.id'))
	title = db.Column(db.Text, server_default='')
	text = db.Column(db.Text, server_default='')
	device_token = db.Column(db.Text, server_default='')
	time = db.Column(db.DateTime, index=True, default=datetime.datetime.utcnow)

class Hujjaj_Announcements(db.Model):
	__tablename__ = "hujjaj_announcements"

	id = db.Column(db.Integer, primary_key = True)
	hamlah_id = db.Column(db.Integer, db.ForeignKey('hamlat.id'))
	hujjaj_id = db.Column(db.Integer, db.ForeignKey('hujjaj.id'))
	title = db.Column(db.Text, server_default='')
	text = db.Column(db.Text, server_default='')
	device_udid = db.Column(db.Text, server_default='')
	device_token = db.Column(db.Text, server_default='')
	time = db.Column(db.DateTime, index=True, default=datetime.datetime.utcnow)


def hajj_management_token_required(f):
	@wraps(f)
	def decorated(*args, **kwargs):
		token = None

		if 'token' in request.headers:
			token = request.headers['token']

		if not token:
			return jsonify({'message' : 'Token is missing!'}), 401

		try: 
			data = jwt.decode(token, app.config['SECRET_KEY'])
			current_user = Hajj_Management.query.filter_by(secret_code=data['secret_code']).first()
			if not current_user:
				message = {"status": "error", "message": "Hajj Management account is not found."}
				return jsonify(message)
		except:
			return jsonify({'message' : 'Token is invalid!'}), 401

		return f(current_user, *args, **kwargs)

	return decorated

def hamlat_token_required(f):
	@wraps(f)
	def decorated(*args, **kwargs):
		token = None

		if 'token' in request.headers:
			token = request.headers['token']

		if not token:
			return jsonify({'message' : 'Token is missing!'}), 401

		try: 
			data = jwt.decode(token, app.config['SECRET_KEY'])
			current_user = Hamlat.query.filter_by(secret_code=data['secret_code']).first()
			if not current_user:
				message = {"status": "error", "message": "Hamlat account is not found."}
				return jsonify(message)
		except:
			return jsonify({'message' : 'Token is invalid!'}), 401

		return f(current_user, *args, **kwargs)

	return decorated

def hujjaj_token_required(f):
	@wraps(f)
	def decorated(*args, **kwargs):
		token = None

		if 'token' in request.headers:
			token = request.headers['token']

		if not token:
			return jsonify({'message' : 'Token is missing!'}), 401

		try: 
			data = jwt.decode(token, app.config['SECRET_KEY'])
			current_user = Hujjaj.query.filter_by(secret_code=data['secret_code']).first()
			if not current_user:
				message = {"status": "error", "message": "Hujjaj account is not found."}
				return jsonify(message)
		except:
			return jsonify({'message' : 'Token is invalid!'}), 401

		return f(current_user, *args, **kwargs)

	return decorated


@app.route("/")
def main():
	code = uuid.uuid4().hex
	return render_template("index.html")



@app.route("/generate-hajj-management-account", methods=["GET","POST"])
def generate_hajj_management_account():
	# return render_template_string('''<img id="qrcode" src="{{ url_for('qrcode') }}">''')

	if request.method == "GET":
		return render_template("register-hajj-management.html")

	else:

		if request.form['submit'] == "register":

			name = request.form.get("name")
			password = request.form.get("password")

			if not name:
				
				flash("You must complete the form!." , "danger")
				return render_template_string("register-hajj-management.html")

			secret_code = generate_unique_management_uuid()
			
			print name
			print secret_code
			
			add_hm = Hajj_Management(name=name, password=password, secret_code=secret_code)

			db.session.add(add_hm)
			db.session.commit()

			session["type"] = "hajj-management"

			session['code'] = secret_code

			flash("please use QR-Code on the App!." , "success")
			return render_template("hajj_management_qrcode.html")


@app.route("/generate-hamlat-account", methods=["POST"])
@hajj_management_token_required
def generate_hamlat_account(current_user):

	name = request.form.get("name")
	email = request.form.get("email")

	if not name or not email:
		
		message = {"status": "error", "message": "You must complete the form!"}
		
		return jsonify(message)

	secret_code = generate_unique_hamlat_uuid()
	
	
	add_hamlat = Hamlat(name=name, email=email, secret_code=secret_code, hajj_management_id = current_user.id)

	db.session.add(add_hamlat)
	db.session.commit()
	
	url = url_for("confirm_hamlat_account", token=secret_code, _external=True)
	
	msg = Message('Registered for Hamlah', sender=app.config["MAIL_SERVER"], recipients=[email])
	msg.body = 'Thank you for registering for Hamlah account, please visit this link and scan your code. \n ' + url
	msg.html = render_template_string('''Thank you for registering for Hamlah account, please visit this link and scan your code. <br/> <a href="{{ url }}" class="btn btn-primary btn-block" role="button">Done</a>''', url=url)
	
	mail.send(msg)
	print jwt.encode({"name": add_hamlat.name, "secret_code": add_hamlat.secret_code}, app.config['SECRET_KEY'], "HS256" )
	
	message = {"status": "ok", "text": "Hamlah account has been created", "secret":secret_code}
	return jsonify(message)


@app.route("/confirm-hamlat-account/<token>", methods=["GET"])
def confirm_hamlat_account(token):
	get_hamlah = Hamlat.query.filter_by(secret_code=token).first()
	if get_hamlah == None:
		abort(404)
	
	
	session["type"] = "hamlah"

	session['code'] = get_hamlah.secret_code

	flash("please use QR-Code on the App!." , "success")
	return render_template("hamlat_qrcode.html")
	
	
@app.route("/generate-hujjaj-account", methods=["POST"])
@hamlat_token_required
def generate_hujjaj_account(current_user):
	
	print "h1"
	
	name = request.form.get("name")
	email = request.form.get("email")
	leaving_date = request.form.get("leaving_date")
	
	#photo = request.files['photo']
	
	
	print "h1"

	if not name or not email or "photo" not in request.files or not leaving_date:
		
		message = {"status": "error", "message": "You must complete the form!"}
		
		return jsonify(message)

	photo = request.files['photo']
	
	secret_code = generate_unique_hamlat_uuid()
	
	#uploadFolder = os.path.join(app.config['PHOTOS_FOLDER'], photo.filename)

	
	
	leaving_date = datetime.datetime.fromtimestamp(float(leaving_date))
	
	#add_hujjaj = Hujjaj(name=name, email=email, secret_code=secret_code, hamlah_id = current_user.id, photo_path = filePath, leaving_date=leaving_date)
	
	add_hujjaj = Hujjaj(name=name, email=email, secret_code=secret_code, hamlah_id = current_user.id, leaving_date=leaving_date)
	
	db.session.add(add_hujjaj)
	db.session.flush()
	
	retrieve_user = Hujjaj.query.filter_by(id=add_hujjaj.id).first()
	
	get_extension = photo.filename.split(".")[1]
	
	complete_filename = str(add_hujjaj.id) + "." + get_extension
	
	#filePath = os.path.join(app.config['PHOTOS_FOLDER'], photo.filename)
	filePath = os.path.join(app.config['PHOTOS_FOLDER'], complete_filename)
		
	photo.save(filePath)
	
	retrieve_user.photo_path = filePath
		
	#db.session.add(add_hujjaj)
	db.session.commit()
	
	face_recognize = {}
	
	read_image = face_recognition.load_image_file(str(filePath))
	
	encode_image = face_recognition.face_encodings(read_image)
	
	
	#img2 = face_recognition.load_image_file("biden.jpg")
	#all_face_encodings["biden"] = face_recognition.face_encodings(img2)[0]
	#
	## ... etc ...
	
	recognized = False
	
	if len(encode_image) > 0:
	
		face_recognize[str(retrieve_user.id)] = face_recognition.face_encodings(read_image)[0]
		
		recognized = True
		
		
		if os.path.exists('dataset_faces.dat'):
			
			with open('dataset_faces.dat', 'r') as rf:
				
				old_data = pickle.load(rf)
			
			old_data.update(face_recognize)
			
			with open('dataset_faces.dat', 'w') as f:
				pickle.dump(old_data, f)
		
		else:
			
			with open('dataset_faces.dat', 'w') as f:
				pickle.dump(face_recognize, f)
	
#	
#	all_face_encodings = {}
#	
#	print filePath
#	
#	read_image = face_recognition.load_image_file(filePath)
#	
#	encode_image = face_recognition.face_encodings(read_image)
#	
#	if len(encode_image) > 0:
#		
#		all_face_encodings[str(retrieve_user.id)] = encode_image[0]
#		
#		with open('dataset_faces.dat', 'ab') as f:
#			
#			pickle.dump(all_face_encodings[str(retrieve_user.id)], f)
#	



#	print face_recognition.face_encodings(img1)
#	
#	all_face_encodings[str(retrieve_user.id)] = face_recognition.face_encodings(img1)[0]
	
	

	
	
	url = url_for("confirm_hamlat_account", token=secret_code, _external=True)
	
	msg = Message('Registered for Hajj', sender=app.config["MAIL_SERVER"], recipients=[email])
	msg.body = 'Thank you for registering for Hujjaj account, please visit this link and scan your code. \n ' + url
	msg.html = render_template_string('''Thank you for registering for Hujjaj account, please visit this link and scan your code. <br/> <a href="{{ url }}" class="btn btn-primary btn-block" role="button">Done</a>''', url=url)
	
	mail.send(msg)
	print jwt.encode({"name": add_hujjaj.name, "secret_code": add_hujjaj.secret_code}, app.config['SECRET_KEY'], "HS256" )
	
	message = {"status": "ok", "text": "Hujjaj account has been created", "secret":secret_code, "id": retrieve_user.id, "recognized": recognized}
	return jsonify(message)



@app.route("/confirm-hujjaj-account/<token>", methods=["GET"])
def confirm_hujjaj_account(token):
	get_hujjaj = Hujjaj.query.filter_by(secret_code=token).first()
	if get_hujjaj == None:
		abort(404)
	
	
	session["type"] = "hamlah"

	session['code'] = get_hujjaj.secret_code

	flash("please use QR-Code on the App!." , "success")
	return render_template("hamlat_qrcode.html")
	
############ start qrcode generators ################

@app.route('/hajj_management_qrcode')
def hajj_management_qrcode():
	
	if 'type' in session:
		check_type = session["type"]
		code = session["code"]

		
		get_hajj_management = Hajj_Management.query.filter_by(secret_code=code).first()
		
		if get_hajj_management == None:
			print "2"

			flash("Your secret code is worng!." , "danger")

			return redirect(url_for('ghmc'))

	else:
		print "3"
		abort(404)
	
	print "4"

   	session.clear()

	token = jwt.encode({"name": get_hajj_management.name, "secret_code": get_hajj_management.secret_code}, app.config['SECRET_KEY'], "HS256" )

	print token
	qrcode = pyqrcode.create(token)
	stream = StringIO.StringIO()
	qrcode.svg(stream, scale=3)
	return stream.getvalue().encode('utf-8'), 200, {
	    'Content-Type': 'image/svg+xml',
	    'Cache-Control': 'no-cache, no-store, must-revalidate',
	    'Pragma': 'no-cache',
	    'Expires': '0'}



@app.route('/hamlat_qrcode')
def hamlat_qrcode():

	if 'type' in session:
		check_type = session["type"]
		code = session["code"]
		
		get_hamlah = Hamlat.query.filter_by(secret_code=code).first()
		
		if get_hamlah == None:

			#flash("Your secret code is worng!." , "danger")

			return abort(404)

	else:
		abort(404)

   	session.clear()

	token = jwt.encode({"name": get_hamlah.name, "secret_code": get_hamlah.secret_code}, app.config['SECRET_KEY'], "HS256" )

	print token
	qrcode = pyqrcode.create(token)
	stream = StringIO.StringIO()
	qrcode.svg(stream, scale=3)
	return stream.getvalue().encode('utf-8'), 200, {
	    'Content-Type': 'image/svg+xml',
	    'Cache-Control': 'no-cache, no-store, must-revalidate',
	    'Pragma': 'no-cache',
	    'Expires': '0'}


@app.route('/hujjaj_qrcode')
def hujjaj_qrcode():

	if 'type' in session:
		check_type = session["type"]
		code = session["code"]

		if type == "hujjaj":

			if Hujjaj.query.filter_by(secret_code=code).first() == None:

				flash("Your secret code is worng!." , "danger")

				return redirect(url_for('main'))
		else:
			return "this code is not for hujjaj."

	else:
		abort(404)


	session.clear()

	url = pyqrcode.create(code)
	stream = StringIO.StringIO()
	url.svg(stream, scale=3)
	return stream.getvalue().encode('utf-8'), 200, {
	    'Content-Type': 'image/svg+xml',
	    'Cache-Control': 'no-cache, no-store, must-revalidate',
	    'Pragma': 'no-cache',
	    'Expires': '0'}
	
############ end qrcode generators ################


######### start fucntions ##########

def generate_unique_management_uuid():

	
	check = False
	
	while check != True:
	
		random_code = uuid.uuid4().get_hex().upper()

		if Hajj_Management.query.filter_by(secret_code=random_code).first() == None:

			return str(random_code)

		else:

			check = False
		
	
	return "none"

def generate_unique_hamlat_uuid():

	
	check = False
	
	while check != True:
	
		random_code = uuid.uuid4().get_hex().upper() + uuid.uuid4().get_hex().upper()

		if Hamlat.query.filter_by(secret_code=random_code).first() == None:

			return str(random_code)

		else:

			check = False
		
	
	return "none"

def generate_unique_hujjaj_uuid():

	
	check = False
	
	while check != True:
	
		random_code = uuid.uuid4().get_hex().upper() + uuid.uuid4().get_hex().upper() + uuid.uuid4().get_hex().upper()

		if Hujjaj.query.filter_by(secret_code=random_code).first() == None:

			return str(random_code)

		else:

			check = False
		
	
	return "none"
	
######### end fucntions ##########
	

@app.route("/gethamlat", methods=["GET"])
@hajj_management_token_required
def get_hamlat(current_user):
	
	#gethamlat = Hajj_Management.query.filter_by(secret_code=current_user.secret_code).first()
	
	hamlat = Hamlat.query.all()
	
	hamlat_list = []
	
	total_hujjaj = 0
	
	for hamlah in hamlat:
		temp = {"id": hamlah.id,
				"name": hamlah.name,
				"secret_code": hamlah.secret_code,
				"latitude" : hamlah.latitude,
				"longitude" : hamlah.longitude,
				"hujjaj_count": hamlah.hujjaj.count(),
				"time": hamlah.time}
		
		total_hujjaj = total_hujjaj + hamlah.hujjaj.count()
		
		hamlat_list.append(temp)
	
	message = {"status": "ok",
				"total_hujjaj_count": total_hujjaj,
				"hamlat": hamlat_list}
	return jsonify(message)

@app.route("/gethujjaj", methods=["GET"])
@hamlat_token_required
def get_hujjaj(current_user):
	
#	hujjaj = Hamlat.query.all()
	#sec = "26CAFB49D9444C8DAA23D8545CCF3E9AE745DBCC79E140888B68CFC3DB2A33FE"
	#gethamlah = Hamlat.query.filter_by(secret_code=current_user.secret_code).first()
	gethamlah = Hamlat.query.filter_by(secret_code=current_user.secret_code).first()
		
	hujjaj_list = []
	
	print gethamlah.id
	print gethamlah.hujjaj
	
	
	for hajj in gethamlah.hujjaj:
		temp = {"id": hajj.id,
				"name": hajj.name,
				"secret_code": hajj.secret_code,
				"photo": url_for('download_photos', photo=hajj.photo_path, _external=True),
				"latitude" : hajj.latitude,
				"longitude" : hajj.longitude,
				"leaving_date": hajj.leaving_date,
				"time": hajj.time}
		hujjaj_list.append(temp)
	
	message = {"status": "ok",
				"hujjaj": hujjaj_list}
	return jsonify(message)

@app.route("/gethajj/<int:id>", methods = ["GET"])
def get_hajj(id):
	
	hajj = Hujjaj.query.filter_by(id=id).first()
	
	message = {}
	
	if hajj:
	
		
	
		message["status"] = "ok"
		
		
		temp = {"id": hajj.id,
				"name": hajj.name,
				"secret_code": hajj.secret_code,
				"photo": url_for('download_photos', photo=hajj.photo_path, _external=True),
				"latitude" : hajj.latitude,
				"longitude" : hajj.longitude,
				"leaving_date": hajj.leaving_date,
				"nationality": nationality,
				"bloodtype": bloodtype,
				"permission_number": permission_number,
				"language": language,
				"time": hajj.time}
				
				
		message["result"] = temp
		
	else:
		
		message["status"] = "error"
		
		message["message"] = "couldn't find hajj"
	
	return jsonify(message)
	
		
		

@app.route("/updatehamlat", methods=["PUT"])
@hamlat_token_required
def update_hamlat(current_user):
	
	gethamlah = Hamlat.query.filter_by(secret_code=current_user.secret_code).first()
	
	device_token = request.form.get("device_token")
	latitude = request.form.get("latitude")
	longitude = request.form.get("longitude")
	
	if not device_token or not latitude or not longitude:
		message = {"status": "error", "message": "device_token, latitude and longitude are required!"}
		return jsonify(message)
	
	gethamlah.device_token = device_token
	gethamlah.latitude = latitude
	gethamlah.longitude = longitude
	
	db.session.commit()
	
	message = {"status": "ok"}
	
	return jsonify(message)


@app.route("/updatehujjaj", methods=["PUT"])
@hujjaj_token_required
def update_hujjaj(current_user):
	
	
	device_token = request.form.get("device_token")
	latitude = request.form.get("latitude")
	longitude = request.form.get("longitude")
	
	if not device_token or not latitude or not longitude:
		message = {"status": "error", "message": "device_token, latitude and longitude are required!"}
		return jsonify(message)
	
	gethujjaj = Hujjaj.query.filter_by(secret_code=current_user.secret_code).first()
	
	gethujjaj.device_token = device_token
	gethujjaj.latitude = latitude
	gethujjaj.longitude = longitude
	
	db.session.commit()
	
	message = {"status": "ok"}
	
	return jsonify(message)


@app.route("/getdates", methods=["GET"])
def get_dates():
	
#	array = [{"day":"يوم التروية","date":"١٤٣٩/١٢/٨"},
#	{"day":"يوم عرفة","date":"١٤٣٩/١٢/٩"},
#	{"day":"يوم عيد الأضحى","date":"١٤٣٩/١٢/١٠"},
#	{"day":"اليوم الحادي","date":"١٤٣٩/١٢/١١"},
#	{"day":"اليوم الثاني عشر من ذي الحجة","date":"١٤٣٩/١٢/١٢"}]
	
	dates = [{"day":"يوم التروية","date":"١٤٣٩/١٢/٨","description":"اليوم الأول: وهو اليوم الثامن من ذي الحجة ويسمّى بيوم التروية."},
		{"day":"يوم عرفة","date":"١٤٣٩/١٢/٩","description":"اليوم الثاني: وهو اليوم التاسع من ذي الحجة وأهم أعماله الوقوف بعرفة."},
		{"day":"يوم عيد الأضحى","date":"١٤٣٩/١٢/١٠","description":"اليوم الثالث: وهو اليوم العاشر من ذي الحجة يوم النحر، وهو أول أيام عيد الأضحى المبارك."},
		{"day":"اليوم الحادي عشر من ذي الحجة","date":"١٤٣٩/١٢/١١","description":"اليوم الرابع: وهو اليوم الحادي عشر من ذي الحجة."},
		{"day":"اليوم الثاني عشر من ذي الحجة","date":"١٤٣٩/١٢/١٢","description":"اليوم الخامس: وهو اليوم الثاني عشر من ذي الحجة."},
		{"day":"اليوم الثالث عشر من ذي الحجة","date":"١٤٣٩/١٢/١٣","description":"اليوم السادس: وهو اليوم الثالث عشر من ذي الحجة، رابع ايام عيد الأضحى المبارك ويكون فيه طواف الوداع."}]
	
	return jsonify(dates)

@app.route("/<path:photo>")
def download_photos(photo):
	print app.config["STATIC_FOLDER"]
	return send_from_directory(app.config["STATIC_FOLDER"], photo, as_attachment=False)


def create_random_point(x0,y0,radius):
	"""
	Utility method for simulation of the points
	"""   
	
	radius = radius * 100
	r = radius / 111300
	u = np.random.uniform(0,1)
	v = np.random.uniform(0,1)
	#print u
	u = random.uniform(0,1)
	#print u
	v = random.uniform(0,1)
	w = r * np.sqrt(u)
	t = 2 * np.pi * v
	x = w * np.cos(t)
	x1 = x / np.cos(y0)
	y = w * np.sin(t)
	return (x0+x1, y0 +y)

@app.route("/create-random-point/<latitude>/<longitude>/<radius>/<count>", methods=["GET"])
def create_random_points(latitude, longitude, radius, count):
#	latitude = request.form.get("latitude")
#	longitude = request.form.get("longitude")
#	radius = request.form.get("radius")
#	count = request.form.get("count")
#	
#	latitude = String(latitude)
#	
	latitude = float(latitude)
	
	longitude = float(longitude)
	radius = float(radius)
	count = int(count)
	
	tempList = []
	
	for i in range(count):
	
		new_latitude, new_longitude = create_random_point(latitude,longitude , radius)
		
		new_distance = haversine((new_latitude, new_longitude),(latitude, longitude))
		
		
		json = {"old_latitude": latitude,
				"old_longitude": longitude,
				"old_radius": radius,
				"new_latitude": new_latitude,
				"new_longitude": new_longitude,
				"new_distance": new_distance}
					
		tempList.append(json)
	
	message = {"status": "ok",
				"results": tempList}
	
	return jsonify(message)

@app.route("/detect-face", methods = ["POST"])
def face():
	
	message = {}
	
	if "photo" in request.files:
		
		photo = request.files['photo']
		
		try:
		
			filePath = os.path.join(app.config['TEMP_PHOTOS_FOLDER'], photo.filename)
					
			photo.save(filePath)
			
			#print photo_content
			
			with open('dataset_faces.dat', 'rb') as f:
				all_face_encodings = pickle.load(f)

			# Grab the list of names and the list of encodings
			#print list(all_face_encodings.keys())
			face_names = list(all_face_encodings.keys())
			face_encodings = np.array(list(all_face_encodings.values()))
			
			print face_names

			# Try comparing an unknown image
			#print photo
			unknown_image = face_recognition.load_image_file(filePath)
			unknown_face = face_recognition.face_encodings(unknown_image)

			results = face_recognition.compare_faces(face_encodings, unknown_face)
			
			print face_names
			print results
			
			
			message["status"] = "ok"
			message["results"] = []
			
			
	
			for index in range(len(results)):
				if results[index] == True:
					print results[index]
					print face_names[index]
					tempDict = {}
					#index = results.index(result)
					print index
					getuser = Hujjaj.query.filter_by(id=int(face_names[index])).first()
					tempDict["name"] = getuser.name
					tempDict["id"] = getuser.id
					
					message["results"].append(tempDict)
			
			print message
		
		
			
		
		except:
			
			
			message["status"] = "error"
			message["message"] = "face couldn't found"
			message["results"] = []
		
	else:
		
		message["status"] = "error"
		message["message"] = "must send photo"
	
	return jsonify(message)
	
	
db.create_all()

if __name__ == "__main__":
	app.run(host="localhost", port=5000)

